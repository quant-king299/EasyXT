import logging

logger = logging.getLogger(__name__)
#!/usr/bin/env python3
"""
测试脚本：验证easy_xt模块作者信息显示
"""

import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_author_info():
    """测试作者信息显示"""
    logger.info("测试easy_xt模块作者信息显示...")
    logger.info("=" * 40)
    
    # 导入easy_xt模块
    import easy_xt
    
    logger.info("\n模块导入成功！")
    logger.info(f"版本: {easy_xt.__version__}")
    logger.info(f"作者: {easy_xt.__author__}")
    
    logger.info("\n" + "=" * 40)
    logger.info("测试完成！")

if __name__ == "__main__":
    test_author_info()