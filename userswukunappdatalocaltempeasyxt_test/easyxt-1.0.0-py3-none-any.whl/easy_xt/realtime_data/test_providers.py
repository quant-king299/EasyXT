import logging

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)



logger = logging.getLogger(__name__)

"""

测试实时数据提供者 - 东方财富和通达信

"""

import sys

import os



# 确保编码正确

import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')



# 添加当前目录到路径

current_dir = os.path.dirname(os.path.abspath(__file__))

if current_dir not in sys.path:

    sys.path.insert(0, current_dir)





def test_eastmoney_provider():

    """测试东方财富数据提供者"""

    logger.info("\n" + "=" * 70)

    logger.info("测试1: 东方财富数据提供者")

    logger.info("=" * 70)



    try:

        from providers.eastmoney_provider import EastmoneyDataProvider



        # 初始化

        provider = EastmoneyDataProvider()

        logger.info("[OK] 模块导入成功")



        # 测试连接

        logger.info("\n[测试] 连接数据源...")

        if provider.connect():

            logger.info("[OK] 连接成功")



            # 测试获取实时行情

            logger.info("\n[测试] 获取实时行情（000001, 600000）...")

            quotes = provider.get_realtime_quotes(['000001', '600000'])



            if quotes:

                logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

                for quote in quotes[:2]:  # 显示前2个

                    print(f"  - {quote.get('name')}({quote.get('symbol')}): "

                          f"价格={quote.get('price'):.2f}, "

                          f"涨跌幅={quote.get('change_pct'):.2f}%")

            else:

                logger.warning("[WARN] 未获取到行情数据")



            # 测试获取热门股票

            logger.info("\n[测试] 获取热门股票...")

            hot_stocks = provider.get_hot_stocks(market='all', count=5)



            if hot_stocks:

                logger.info(f"[OK] 成功获取 {len(hot_stocks)} 只热门股票")

                for stock in hot_stocks[:3]:

                    print(f"  - {stock.get('rank')}. {stock.get('name')}({stock.get('symbol')}): "

                          f"主力净流入={stock.get('main_net_inflow'):.2f}万")

            else:

                logger.warning("[WARN] 未获取到热门股票数据")



            # 测试获取板块数据

            logger.info("\n[测试] 获取行业板块数据...")

            sectors = provider.get_sector_data(sector_type='industry')



            if sectors:

                logger.info(f"[OK] 成功获取 {len(sectors)} 个行业板块")

                for sector in sectors[:3]:

                    logger.info(f"  - {sector.get('name')}: 涨跌幅={sector.get('change_pct'):.2f}%")

            else:

                logger.warning("[WARN] 未获取到板块数据")



            # 断开连接

            provider.disconnect()

            logger.info("\n[OK] 测试完成")

            return True



        else:

            logger.error("[ERROR] 连接失败")

            return False



    except ImportError as e:

        logger.error(f"[ERROR] 模块导入失败: {e}")

        return False

    except Exception as e:

        logger.error(f"[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def test_tdx_provider():

    """测试通达信数据提供者（基础版）"""

    logger.info("\n" + "=" * 70)

    logger.info("测试2: 通达信数据提供者（基础版）")

    logger.info("=" * 70)



    try:

        from providers.tdx_provider import TdxDataProvider



        # 初始化

        provider = TdxDataProvider()

        logger.info("[OK] 模块导入成功")



        # 测试连接

        logger.info("\n[测试] 连接通达信服务器...")

        if provider.connect():

            logger.info(f"[OK] 连接成功 - 服务器: {provider.current_server.get('name', 'Unknown')}")



            # 测试获取实时行情

            logger.info("\n[测试] 获取实时行情（000001, 600000）...")

            quotes = provider.get_realtime_quotes(['000001', '600000'])



            if quotes:

                logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

                for quote in quotes[:2]:

                    print(f"  - {quote.get('name')}({quote.get('code')}): "

                          f"价格={quote.get('price'):.2f}, "

                          f"涨跌幅={quote.get('change_pct'):.2f}%")

            else:

                logger.warning("[WARN] 未获取到行情数据")



            # 测试获取市场状态

            logger.info("\n[测试] 获取市场状态...")

            status = provider.get_market_status()



            if status:

                logger.info(f"[OK] 深市股票数: {status.get('sz_market_count', 0)}")

                logger.info(f"[OK] 沪市股票数: {status.get('sh_market_count', 0)}")

            else:

                logger.warning("[WARN] 未获取到市场状态")



            # 断开连接

            provider.disconnect()

            logger.info("\n[OK] 测试完成")

            return True



        else:

            logger.error("[ERROR] 连接失败（可能是网络问题或服务器不可用）")

            return False



    except ImportError as e:

        logger.error(f"[ERROR] 模块导入失败: {e}")

        logger.info("  提示: 需要安装 pytdx - pip install pytdx")

        return False

    except Exception as e:

        logger.error(f"[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def test_tdx_provider_enhanced():

    """测试通达信数据提供者（增强版）"""

    logger.info("\n" + "=" * 70)

    logger.info("测试3: 通达信数据提供者（增强版）")

    logger.info("=" * 70)



    try:

        from providers.tdx_provider_enhanced import TdxDataProviderEnhanced



        # 初始化

        provider = TdxDataProviderEnhanced()

        logger.info("[OK] 模块导入成功")



        # 测试连接

        logger.info("\n[测试] 连接通达信服务器（增强版）...")

        if provider.connect():

            logger.info(f"[OK] 连接成功 - 服务器: {provider.current_server.get('name', 'Unknown')}")



            # 测试获取实时行情

            logger.info("\n[测试] 获取实时行情（000001, 600000）...")

            quotes = provider.get_realtime_quotes(['000001', '600000'])



            if quotes:

                logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

                for quote in quotes[:2]:

                    print(f"  - {quote.get('name')}({quote.get('code')}): "

                          f"价格={quote.get('price'):.2f}, "

                          f"涨跌幅={quote.get('change_pct'):.2f}%")

            else:

                logger.warning("[WARN] 未获取到行情数据")



            # 测试获取服务器状态

            logger.info("\n[测试] 获取服务器状态...")

            status = provider.get_server_status()



            if status:

                logger.info(f"[OK] 总服务器数: {status.get('total_servers', 0)}")

                logger.info(f"[OK] 可用服务器数: {status.get('available_servers', 0)}")

            else:

                logger.warning("[WARN] 未获取到服务器状态")



            # 断开连接

            provider.disconnect()

            logger.info("\n[OK] 测试完成")

            return True



        else:

            logger.error("[ERROR] 连接失败（可能是网络问题或服务器不可用）")

            return False



    except ImportError as e:

        logger.error(f"[ERROR] 模块导入失败: {e}")

        logger.info("  提示: 需要安装 pytdx - pip install pytdx")

        return False

    except Exception as e:

        logger.error(f"[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def main():

    """主测试函数"""

    logger.info("\n")

    logger.info("╔" + "=" * 68 + "╗")

    logger.info("║" + " " * 15 + "实时数据提供者测试" + " " * 31 + "║")

    logger.info("╚" + "=" * 68 + "╝")



    results = []



    # 测试东方财富

    results.append(("东方财富", test_eastmoney_provider()))



    # 测试通达信基础版

    results.append(("通达信基础版", test_tdx_provider()))



    # 测试通达信增强版

    results.append(("通达信增强版", test_tdx_provider_enhanced()))



    # 汇总结果

    logger.info("\n" + "=" * 70)

    logger.info("测试汇总")

    logger.info("=" * 70)



    pass_count = sum(1 for _, result in results if result)

    total_count = len(results)



    for name, result in results:

        status = "✓ PASS" if result else "✗ FAIL"

        logger.info(f"{status:10s} {name}")



    logger.info("=" * 70)

    logger.info(f"测试通过率: {pass_count}/{total_count} ({pass_count/total_count*100:.1f}%)")

    logger.info("=" * 70)



    # 使用建议

    logger.info("\n使用建议:")

    logger.info("1. 东方财富: 适合获取实时行情、热门股票、板块数据")

    logger.info("2. 通达信基础版: 适合获取基础行情和K线数据")

    logger.info("3. 通达信增强版: 更多服务器选择，连接更稳定")

    logger.info("\n依赖安装:")

    logger.info("  pip install requests  # 东方财富需要")

    logger.info("  pip install pytdx      # 通达信需要")





if __name__ == "__main__":

    main()

