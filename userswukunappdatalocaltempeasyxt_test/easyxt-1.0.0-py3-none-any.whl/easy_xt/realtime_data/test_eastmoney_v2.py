import logging

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)



logger = logging.getLogger(__name__)

"""

测试更新后的东方财富模块

"""

import sys

import os

import io



# 设置UTF-8编码

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')



current_dir = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, current_dir)





def test_eastmoney_v2():

    """测试更新后的东方财富模块"""

    logger.info("\n" + "=" * 70)

    logger.info("东方财富数据提供者 V2 - 测试")

    logger.info("=" * 70)



    try:

        from providers.eastmoney_provider_v2 import EastmoneyDataProviderV2



        logger.info("\n[1/5] 初始化...")

        provider = EastmoneyDataProviderV2()

        logger.info("[OK] 模块初始化成功")



        # 连接测试

        logger.info("\n[2/5] 连接数据源...")

        if provider.connect():

            logger.info("[OK] 连接成功")

        else:

            logger.info("[FAIL] 连接失败")

            return False



        # 获取实时行情

        logger.info("\n[3/5] 获取实时行情...")

        test_codes = ['000001', '600000', '000002']

        quotes = provider.get_realtime_quotes(test_codes)



        if quotes:

            logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

            logger.info("\n股票详情:")

            for q in quotes:

                print(f"  {q.get('name')}({q.get('symbol')}): "

                      f"价格={q.get('price'):.2f}, "

                      f"涨跌={q.get('change'):+.2f} ({q.get('change_pct'):+.2f}%)")

        else:

            logger.warning("[WARN] 未获取到行情数据")



        # 获取热门股票

        logger.info("\n[4/5] 获取热门股票...")

        hot_stocks = provider.get_hot_stocks(market='all', count=5)



        if hot_stocks:

            logger.info(f"[OK] 成功获取 {len(hot_stocks)} 只热门股票")

            logger.info("\n热门股票TOP5:")

            for s in hot_stocks[:5]:

                print(f"  {s.get('rank')}. {s.get('name')}({s.get('symbol')}): "

                      f"主力净流入={s.get('main_net_inflow')/10000:.2f}万元")

        else:

            logger.warning("[WARN] 未获取到热门股票")



        # 获取板块数据

        logger.info("\n[5/5] 获取行业板块数据...")

        sectors = provider.get_sector_data(sector_type='industry')



        if sectors:

            logger.info(f"[OK] 成功获取 {len(sectors)} 个行业板块")

            logger.info("\n涨幅榜TOP5:")

            for s in sectors[:5]:

                print(f"  {s.get('rank')}. {s.get('name')}: "

                      f"涨跌幅={s.get('change_pct'):+.2f}%")

        else:

            logger.warning("[WARN] 未获取到板块数据")



        # 断开连接

        provider.disconnect()

        logger.info("\n" + "=" * 70)

        logger.info("[OK] 东方财富V2测试完成")

        logger.info("=" * 70)

        return True



    except Exception as e:

        logger.error(f"\n[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def main():

    """主测试函数"""

    logger.info("\n")

    logger.info("=" * 70)

    logger.info(" " * 20 + "东方财富V2 模块测试")

    logger.info("=" * 70)



    success = test_eastmoney_v2()



    logger.info("\n" + "=" * 70)

    logger.info("测试结果")

    logger.info("=" * 70)



    if success:

        logger.info("[PASS] 东方财富V2模块可用")

        logger.info("\n更新内容:")

        logger.info("1. 更新了User-Agent到最新版本(Chrome 131)")

        logger.info("2. 添加了完整的浏览器请求头")

        logger.info("3. 使用Session复用连接")

        logger.info("4. 添加了多个备用API端点")

        logger.info("5. 改进了错误处理和重试机制")

    else:

        logger.info("[FAIL] 东方财富V2模块仍需调试")

        logger.info("\n可能的原因:")

        logger.info("1. 网络防火墙阻止")

        logger.info("2. 东方财富API进一步更新")

        logger.info("3. 需要更复杂的认证机制")





if __name__ == "__main__":

    main()

