import logging

logger = logging.getLogger(__name__)
"""
服务器配置管理
Windows Server部署专用配置
"""

import os
import json
from typing import Dict, Any, Optional

class ServerConfig:
    """服务器配置类"""
    
    def __init__(self, config_file: Optional[str] = None):
        """初始化配置
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file or "config/server_config.json"
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        default_config = {
            "server": {
                "name": "EasyXT Realtime Data Service",
                "version": "1.0.0",
                "environment": "production"
            },
            "http": {
                "host": "0.0.0.0",
                "port": 8080,
                "debug": False,
                "cors_enabled": True,
                "cors_origins": ["*"],
                "max_connections": 1000,
                "timeout": 30
            },
            "websocket": {
                "host": "0.0.0.0", 
                "port": 8765,
                "max_connections": 500,
                "ping_interval": 20,
                "ping_timeout": 10,
                "close_timeout": 10
            },
            "data_sources": {
                "tdx": {
                    "enabled": True,
                    "priority": 1,
                    "timeout": 5,
                    "retry_count": 3,
                    "servers": [
                        {"host": "119.147.212.81", "port": 7709},
                        {"host": "114.80.63.12", "port": 7709},
                        {"host": "180.153.39.51", "port": 7709}
                    ]
                },
                "ths": {
                    "enabled": True,
                    "priority": 2,
                    "timeout": 5,
                    "retry_count": 3
                },
                "eastmoney": {
                    "enabled": True,
                    "priority": 3,
                    "timeout": 5,
                    "retry_count": 3
                }
            },
            "cache": {
                "enabled": True,
                "type": "memory",  # memory, redis
                "memory": {
                    "max_size": 1000,
                    "ttl": 300
                },
                "redis": {
                    "host": "localhost",
                    "port": 6379,
                    "db": 0,
                    "password": None,
                    "ttl": 300
                }
            },
            "logging": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "file": "logs/easyxt_service.log",
                "max_size": "10MB",
                "backup_count": 5
            },
            "monitoring": {
                "enabled": True,
                "metrics_interval": 60,
                "health_check_interval": 30,
                "alert_thresholds": {
                    "memory_usage": 80,
                    "cpu_usage": 80,
                    "response_time": 2.0,
                    "error_rate": 0.05
                }
            },
            "security": {
                "api_key_required": False,
                "rate_limiting": {
                    "enabled": True,
                    "requests_per_minute": 1000,
                    "burst_size": 100
                },
                "ip_whitelist": [],
                "ip_blacklist": []
            }
        }
        
        # 尝试加载配置文件
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    file_config = json.load(f)
                    # 合并配置
                    self._merge_config(default_config, file_config)
            except Exception as e:
                logger.info(f"警告: 加载配置文件失败 {e}，使用默认配置")
        
        return default_config
    
    def _merge_config(self, default: Dict[str, Any], override: Dict[str, Any]):
        """递归合并配置"""
        for key, value in override.items():
            if key in default and isinstance(default[key], dict) and isinstance(value, dict):
                self._merge_config(default[key], value)
            else:
                default[key] = value
    
    def save_config(self):
        """保存配置到文件"""
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    @property
    def HTTP_HOST(self) -> str:
        return self.config["http"]["host"]
    
    @property
    def HTTP_PORT(self) -> int:
        return self.config["http"]["port"]
    
    @property
    def WEBSOCKET_HOST(self) -> str:
        return self.config["websocket"]["host"]
    
    @property
    def WEBSOCKET_PORT(self) -> int:
        return self.config["websocket"]["port"]
    
    def get_http_config(self) -> Dict[str, Any]:
        """获取HTTP配置"""
        return self.config["http"]
    
    def get_websocket_config(self) -> Dict[str, Any]:
        """获取WebSocket配置"""
        return self.config["websocket"]
    
    def get_data_source_config(self, source: str) -> Dict[str, Any]:
        """获取数据源配置"""
        return self.config["data_sources"].get(source, {})
    
    def get_cache_config(self) -> Dict[str, Any]:
        """获取缓存配置"""
        return self.config["cache"]
    
    def get_logging_config(self) -> Dict[str, Any]:
        """获取日志配置"""
        return self.config["logging"]
    
    def get_monitoring_config(self) -> Dict[str, Any]:
        """获取监控配置"""
        return self.config["monitoring"]
    
    def get_security_config(self) -> Dict[str, Any]:
        """获取安全配置"""
        return self.config["security"]
    
    def update_config(self, key_path: str, value: Any):
        """更新配置值
        
        Args:
            key_path: 配置路径，如 'http.port'
            value: 新值
        """
        keys = key_path.split('.')
        config = self.config
        
        # 导航到目标位置
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        # 设置值
        config[keys[-1]] = value
    
    def is_production(self) -> bool:
        """是否为生产环境"""
        return self.config["server"]["environment"] == "production"
    
    def is_debug(self) -> bool:
        """是否为调试模式"""
        return self.config["http"]["debug"]