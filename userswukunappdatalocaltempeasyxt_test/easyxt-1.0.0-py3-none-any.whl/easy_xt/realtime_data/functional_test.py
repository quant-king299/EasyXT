import logging

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)



logger = logging.getLogger(__name__)

"""

实时数据提供者功能测试

"""

import sys

import os

import io



# 设置UTF-8编码

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')



current_dir = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, current_dir)





def test_eastmoney():

    """测试东方财富功能"""

    logger.info("\n" + "=" * 70)

    logger.info("东方财富数据提供者 - 功能测试")

    logger.info("=" * 70)



    try:

        from providers.eastmoney_provider import EastmoneyDataProvider

        provider = EastmoneyDataProvider()



        # 连接

        logger.info("\n[1/4] 连接数据源...")

        if provider.connect():

            logger.info("[OK] 连接成功")

        else:

            logger.info("[FAIL] 连接失败")

            return False



        # 获取实时行情

        logger.info("\n[2/4] 获取实时行情...")

        test_codes = ['000001', '600000', '000002']

        quotes = provider.get_realtime_quotes(test_codes)



        if quotes:

            logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

            logger.info("\n股票详情:")

            for q in quotes:

                print(f"  {q.get('name')}({q.get('symbol')}): "

                      f"价格={q.get('price'):.2f}, "

                      f"涨跌={q.get('change'):+.2f} ({q.get('change_pct'):+.2f}%)")

        else:

            logger.warning("[WARN] 未获取到行情数据")



        # 获取热门股票

        logger.info("\n[3/4] 获取热门股票...")

        hot_stocks = provider.get_hot_stocks(market='all', count=5)



        if hot_stocks:

            logger.info(f"[OK] 成功获取 {len(hot_stocks)} 只热门股票")

            logger.info("\n热门股票TOP5:")

            for s in hot_stocks[:5]:

                print(f"  {s.get('rank')}. {s.get('name')}({s.get('symbol')}): "

                      f"主力净流入={s.get('main_net_inflow')/10000:.2f}亿")

        else:

            logger.warning("[WARN] 未获取到热门股票")



        # 获取板块数据

        logger.info("\n[4/4] 获取行业板块数据...")

        sectors = provider.get_sector_data(sector_type='industry')



        if sectors:

            logger.info(f"[OK] 成功获取 {len(sectors)} 个行业板块")

            logger.info("\n涨幅榜TOP5:")

            for s in sectors[:5]:

                print(f"  {s.get('rank')}. {s.get('name')}: "

                      f"涨跌幅={s.get('change_pct'):+.2f}%, "

                      f"领涨股={s.get('leader_symbol')}")

        else:

            logger.warning("[WARN] 未获取到板块数据")



        provider.disconnect()

        logger.info("\n[OK] 东方财富测试完成")

        return True



    except Exception as e:

        logger.error(f"\n[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def test_tdx():

    """测试通达信功能"""

    logger.info("\n" + "=" * 70)

    logger.info("通达信数据提供者 - 功能测试")

    logger.info("=" * 70)



    try:

        from providers.tdx_provider import TdxDataProvider

        provider = TdxDataProvider()



        # 连接

        logger.info("\n[1/3] 连接通达信服务器...")

        if provider.connect():

            logger.info(f"[OK] 连接成功")

            logger.info(f"  服务器: {provider.current_server.get('name', 'Unknown')}")

            logger.info(f"  地址: {provider.current_server.get('host')}:{provider.current_server.get('port')}")

        else:

            logger.info("[FAIL] 连接失败")

            return False



        # 获取实时行情

        logger.info("\n[2/3] 获取实时行情...")

        test_codes = ['000001', '600000', '000002']

        quotes = provider.get_realtime_quotes(test_codes)



        if quotes:

            logger.info(f"[OK] 成功获取 {len(quotes)} 只股票行情")

            logger.info("\n股票详情:")

            for q in quotes:

                print(f"  {q.get('name')}({q.get('code')}): "

                      f"价格={q.get('price'):.2f}, "

                      f"涨跌={q.get('change'):+.2f} ({q.get('change_pct'):+.2f}%)")

        else:

            logger.warning("[WARN] 未获取到行情数据")



        # 获取K线数据

        logger.info("\n[3/3] 获取K线数据...")

        kline_data = provider.get_kline_data('000001', period='D', count=5)



        if kline_data:

            logger.info(f"[OK] 成功获取 {len(kline_data)} 条K线数据")

            logger.info("\n最近5日K线:")

            for k in kline_data:

                print(f"  {k.get('datetime')}: "

                      f"开={k.get('open'):.2f}, "

                      f"高={k.get('high'):.2f}, "

                      f"低={k.get('low'):.2f}, "

                      f"收={k.get('close'):.2f}")

        else:

            logger.warning("[WARN] 未获取到K线数据")



        provider.disconnect()

        logger.info("\n[OK] 通达信测试完成")

        return True



    except Exception as e:

        logger.error(f"\n[ERROR] 测试异常: {e}")

        import traceback

        traceback.print_exc()

        return False





def main():

    """主测试函数"""

    logger.info("\n")

    logger.info("=" * 70)

    logger.info(" " * 15 + "实时数据提供者功能测试")

    logger.info("=" * 70)



    results = []



    # 测试东方财富

    results.append(("东方财富", test_eastmoney()))



    # 测试通达信

    results.append(("通达信", test_tdx()))



    # 汇总结果

    logger.info("\n" + "=" * 70)

    logger.info("测试汇总")

    logger.info("=" * 70)



    pass_count = sum(1 for _, result in results if result)

    total_count = len(results)



    for name, result in results:

        status = "[PASS]" if result else "[FAIL]"

        logger.info(f"{status} {name}")



    logger.info("=" * 70)

    logger.info(f"测试通过率: {pass_count}/{total_count} ({pass_count/total_count*100:.0f}%)")

    logger.info("=" * 70)



    if pass_count == total_count:

        logger.info("\n[OK] 所有数据源均可用!")

    elif pass_count > 0:

        logger.warning("\n[WARN] 部分数据源可用")

    else:

        logger.error("\n[ERROR] 所有数据源均不可用，请检查网络连接")





if __name__ == "__main__":

    main()

