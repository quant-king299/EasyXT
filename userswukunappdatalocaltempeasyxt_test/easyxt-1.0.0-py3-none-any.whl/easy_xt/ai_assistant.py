# -*- coding: utf-8 -*-
import logging

logger = logging.getLogger(__name__)
#!/usr/bin/env python3
"""
EasyXT AI助手模块
结合Tushare Skills提供智能量化交易辅助功能

功能：
- 自然语言数据查询
- 智能策略建议
- 代码生成辅助
- 金融数据分析

作者: 王者quant
版本: 1.0.0
"""

import re
import json
import pandas as pd
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import logging

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TushareSkillIntegration:
    """Tushare Skills 集成类"""

    def __init__(self, token: Optional[str] = None):
        """
        初始化Tushare Skills集成

        Args:
            token: Tushare API token，如果不提供则从环境变量读取
        """
        self.token = token
        self.ts_pro = None
        self._initialize_tushare()

    def _initialize_tushare(self):
        """初始化Tushare连接"""
        try:
            import tushare as ts

            # 尝试获取token
            if not self.token:
                # 尝试从环境变量获取
                import os
                from dotenv import load_dotenv
                load_dotenv()
                self.token = os.getenv('TUSHARE_TOKEN')

            if self.token:
                ts.set_token(self.token)
                self.ts_pro = ts.pro_api()
                logger.info("✓ Tushare API 连接成功")
            else:
                logger.warning("⚠ Tushare Token 未配置，部分功能将受限")
        except ImportError:
            logger.warning("⚠ tushare 模块未安装")
        except Exception as e:
            logger.error(f"✗ Tushare 初始化失败: {e}")

    def is_available(self) -> bool:
        """检查Tushare是否可用"""
        return self.ts_pro is not None


class AIQueryEngine:
    """AI查询引擎"""

    def __init__(self, tushare_integration: TushareSkillIntegration):
        self.tushare = tushare_integration
        self.query_patterns = self._build_query_patterns()

    def _build_query_patterns(self) -> Dict[str, Any]:
        """构建查询模式匹配规则"""
        return {
            'stock_price': {
                'keywords': ['价格', '行情', 'K线', '日线', '收盘', '开盘', '数据', '股价', '行情数据'],
                'pattern': r'(?:获取|查询|查看|显示|)(.+?)(?:的|最近|从|到)(?:价格|行情|数据|K线)?'
            },
            'stock_list': {
                'keywords': ['股票列表', '所有股票', '股票代码'],
                'pattern': r'(?:获取|查询|)(?:所有|)(?:股票|A股)(?:列表|代码)'
            },
            'financial_data': {
                'keywords': ['财务', '财报', '市盈率', '市净率', '市值', 'PE', 'PB', '基本面'],
                'pattern': r'(?:查询|获取|分析)(.+?)(?:的|)(?:财务|市盈率|市净率|市值|PE|PB|基本面)'
            },
            'strategy_help': {
                'keywords': ['策略', '交易策略', '回测', '量化策略', '写策略', '开发策略', '生成策略'],
                'pattern': r'(?:帮|协助|)(?:我|)(?:写|做|开发|生成|创建)(.+?)(?:策略|交易策略)?'
            }
        }

    def parse_query(self, query: str) -> Dict[str, Any]:
        """
        解析自然语言查询

        Args:
            query: 自然语言查询字符串

        Returns:
            解析后的查询意图和参数
        """
        query = query.strip()
        intent = {
            'type': 'unknown',
            'confidence': 0.0,
            'params': {},
            'raw_query': query
        }

        # 尝试匹配各种查询模式
        for query_type, pattern_info in self.query_patterns.items():
            keywords = pattern_info['keywords']
            pattern = pattern_info['pattern']

            # 检查关键词匹配
            keyword_matches = sum(1 for kw in keywords if kw in query)

            # 检查模式匹配
            pattern_match = re.search(pattern, query)

            if keyword_matches > 0 or pattern_match:
                confidence = min(0.5 + (keyword_matches * 0.1) + (0.3 if pattern_match else 0), 1.0)

                if confidence > intent['confidence']:
                    intent = {
                        'type': query_type,
                        'confidence': confidence,
                        'params': self._extract_params(query, query_type, pattern_match),
                        'raw_query': query
                    }

        return intent

    def _extract_params(self, query: str, query_type: str, pattern_match) -> Dict[str, Any]:
        """从查询中提取参数"""
        params = {}

        if query_type == 'stock_price':
            # 提取股票代码（即使没有模式匹配也尝试提取）
            stock_ref = pattern_match.group(1) if pattern_match else query
            params['stock_code'] = self._extract_stock_code(query, stock_ref)

            # 提取时间范围
            params['time_range'] = self._extract_time_range(query)

        elif query_type == 'financial_data':
            params['stock_code'] = self._extract_stock_code(query, "")
            params['indicators'] = self._extract_financial_indicators(query)

        elif query_type == 'strategy_help':
            params['strategy_desc'] = query

        return params

    def _extract_stock_code(self, query: str, stock_ref: str) -> Optional[str]:
        """提取股票代码"""
        # 直接匹配6位数字代码
        code_pattern = r'\d{6}'
        codes = re.findall(code_pattern, query + ' ' + stock_ref)

        if codes:
            code = codes[0]
            # 根据代码判断市场
            if code.startswith(('60', '68', '11')):
                return f"{code}.SH"
            elif code.startswith(('00', '30')):
                return f"{code}.SZ"

        # 尝试匹配股票名称
        stock_names = {
            '茅台': '600519.SH', '贵州茅台': '600519.SH',
            '平安': '000001.SZ', '平安银行': '000001.SZ',
            '招行': '600036.SH', '招商银行': '600036.SH',
            '腾讯': '00700.HK',
            '阿里': '09988.HK',
            '比亚迪': '002594.SZ',
            '宁德时代': '300750.SZ',
            '五粮液': '000858.SZ',
            '美的': '000333.SZ', '美的集团': '000333.SZ',
        }

        for name, code in stock_names.items():
            if name in query or name in stock_ref:
                return code

        return None

    def _extract_time_range(self, query: str) -> Dict[str, str]:
        """提取时间范围"""
        time_range = {}

        # 匹配日期范围
        date_patterns = [
            (r'(\d{4})年(\d{1,2})月(\d{1,2})日', '%Y%m%d'),
            (r'(\d{4})-(\d{1,2})-(\d{1,2})', '%Y%m%d'),
            (r'(\d{4})/(\d{1,2})/(\d{1,2})', '%Y%m%d'),
            (r'最近(\d+)(?:天|日)', 'days'),
        ]

        for pattern, format_type in date_patterns:
            matches = re.findall(pattern, query)
            if matches:
                if format_type == 'days':
                    days = int(matches[0][0])
                    end_date = datetime.now()
                    start_date = end_date - timedelta(days=days)
                    time_range['start'] = start_date.strftime('%Y%m%d')
                    time_range['end'] = end_date.strftime('%Y%m%d')
                    return time_range

        # 默认返回最近一年
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)
        time_range['start'] = start_date.strftime('%Y%m%d')
        time_range['end'] = end_date.strftime('%Y%m%d')

        return time_range

    def _extract_financial_indicators(self, query: str) -> List[str]:
        """提取财务指标"""
        indicators = []

        indicator_map = {
            '市盈率': 'pe',
            'PE': 'pe',
            'pe_ttm': 'pe_ttm',
            '市净率': 'pb',
            'PB': 'pb',
            '市值': 'total_mv',
            '总市值': 'total_mv',
            '流通市值': 'circ_mv',
            '股息率': 'dv_ratio',
            '换手率': 'turnover_rate'
        }

        for name, code in indicator_map.items():
            if name in query:
                indicators.append(code)

        return indicators if indicators else ['pe', 'pb', 'total_mv']


class EasyXTAI:
    """EasyXT AI助手主类"""

    def __init__(self, token: Optional[str] = None):
        """
        初始化AI助手

        Args:
            token: Tushare API token
        """
        # 初始化Tushare集成
        self.tushare_integration = TushareSkillIntegration(token)

        # 初始化查询引擎
        self.query_engine = AIQueryEngine(self.tushare_integration)

        # 导入EasyXT API
        try:
            from . import get_api
            self.api = get_api()

            # 自动初始化数据服务
            try:
                self.api.init_data()
                logger.info("✓ EasyXT 数据服务初始化成功")
            except Exception as init_error:
                logger.warning(f"⚠ EasyXT 数据服务初始化失败: {init_error}")
                logger.info("💡 将使用Tushare作为数据源")

            logger.info("✓ EasyXT API 加载成功")
        except Exception as e:
            logger.warning(f"⚠ EasyXT API 加载失败: {e}")
            self.api = None

        logger.info("🤖 EasyXT AI助手初始化完成")

    def query(self, natural_query: str) -> Dict[str, Any]:
        """
        自然语言查询接口

        Args:
            natural_query: 自然语言查询字符串

        Returns:
            查询结果字典

        Examples:
            >>> ai.query("获取茅台最近一个月的价格")
            >>> ai.query("查询平安银行的市盈率")
            >>> ai.query("帮我写一个双均线策略")
        """
        # 解析查询意图
        intent = self.query_engine.parse_query(natural_query)

        result = {
            'query': natural_query,
            'intent': intent['type'],
            'confidence': intent['confidence'],
            'success': False,
            'data': None,
            'message': '',
            'suggestions': []
        }

        try:
            # 根据意图执行相应的操作
            if intent['type'] == 'stock_price':
                result.update(self._handle_stock_price_query(intent))
            elif intent['type'] == 'financial_data':
                result.update(self._handle_financial_query(intent))
            elif intent['type'] == 'strategy_help':
                result.update(self._handle_strategy_query(intent))
            else:
                result['message'] = "抱歉，我无法理解您的查询。请尝试更具体的描述。"
                result['suggestions'] = self._get_query_suggestions()

        except Exception as e:
            result['message'] = f"查询执行出错: {str(e)}"
            logger.error(f"Query failed: {e}")

        return result

    def _handle_stock_price_query(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """处理股票价格查询"""
        params = intent['params']
        stock_code = params.get('stock_code')

        if not stock_code:
            return {
                'success': False,
                'message': '无法识别股票代码，请提供具体的股票代码或名称（如：600519.SH）'
            }

        time_range = params.get('time_range', {})

        try:
            # 优先使用EasyXT API
            if self.api:
                try:
                    data = self.api.get_price(
                        stock_code,
                        start=time_range.get('start', '20230101'),
                        end=time_range.get('end', datetime.now().strftime('%Y%m%d')),
                        period='1d'
                    )

                    if data is not None and not data.empty:
                        return {
                            'success': True,
                            'data': data,
                            'message': f'成功获取 {stock_code} 的价格数据，共 {len(data)} 条记录',
                            'source': 'EasyXT',
                            'summary': self._generate_price_summary(data)
                        }
                except Exception as api_error:
                    logger.warning(f"EasyXT API查询失败，尝试使用Tushare: {api_error}")

            # 降级到Tushare
            if self.tushare_integration.is_available():
                try:
                    data = self.tushare_integration.ts_pro.daily(
                        ts_code=stock_code,
                        start_date=time_range.get('start', '20230101'),
                        end_date=time_range.get('end', datetime.now().strftime('%Y%m%d'))
                    )

                    if data is not None and not data.empty:
                        # 转换数据格式以匹配EasyXT格式
                        if 'trade_date' in data.columns:
                            data.rename(columns={'trade_date': 'date', 'ts_code': 'symbol'}, inplace=True)

                        return {
                            'success': True,
                            'data': data,
                            'message': f'成功获取 {stock_code} 的价格数据，共 {len(data)} 条记录',
                            'source': 'Tushare',
                            'summary': self._generate_price_summary(data)
                        }
                except Exception as tushare_error:
                    logger.warning(f"Tushare查询失败: {tushare_error}")

            return {
                'success': False,
                'message': '无法获取价格数据。请确认：1) 股票代码正确 2) Tushare Token已配置 3) 网络连接正常'
            }

        except Exception as e:
            return {
                'success': False,
                'message': f'价格查询失败: {str(e)}'
            }

    def _handle_financial_query(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """处理财务数据查询"""
        params = intent['params']
        stock_code = params.get('stock_code')

        if not stock_code:
            return {
                'success': False,
                'message': '无法识别股票代码，请提供具体的股票代码或名称'
            }

        try:
            if self.tushare_integration.is_available():
                # 获取最新的交易日
                trade_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')

                # 获取每日基本面数据
                data = self.tushare_integration.ts_pro.daily_basic(
                    ts_code=stock_code,
                    trade_date=trade_date,
                    fields='ts_code,trade_date,pe,pe_ttm,pb,ps,ps_ttm,dv_ratio,total_mv,circ_mv'
                )

                if data is not None and not data.empty:
                    return {
                        'success': True,
                        'data': data,
                        'message': f'成功获取 {stock_code} 的财务数据',
                        'summary': self._generate_financial_summary(data)
                    }

            return {
                'success': False,
                'message': '无法获取财务数据，请确认Tushare Token已配置'
            }

        except Exception as e:
            return {
                'success': False,
                'message': f'财务查询失败: {str(e)}'
            }

    def _handle_strategy_query(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """处理策略开发请求"""
        strategy_desc = intent['params'].get('strategy_desc', '')

        # 生成策略建议
        suggestions = self._generate_strategy_suggestions(strategy_desc)

        return {
            'success': True,
            'message': '我已经理解您的策略需求，以下是一些建议：',
            'suggestions': suggestions,
            'next_steps': [
                '1. 确定策略的具体参数和规则',
                '2. 使用 easyxt_backtest 进行回测',
                '3. 根据回测结果优化策略参数'
            ]
        }

    def _generate_price_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """生成价格数据摘要"""
        if data.empty:
            return {}

        latest = data.iloc[-1]
        earliest = data.iloc[0]

        return {
            'latest_price': float(latest['close']) if 'close' in latest else None,
            'change': float(latest['close'] - earliest['close']) if 'close' in latest else None,
            'change_pct': float((latest['close'] / earliest['close'] - 1) * 100) if 'close' in latest else None,
            'highest': float(data['high'].max()) if 'high' in data else None,
            'lowest': float(data['low'].min()) if 'low' in data else None,
            'volume_avg': float(data['volume'].mean()) if 'volume' in data else None
        }

    def _generate_financial_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """生成财务数据摘要"""
        if data.empty:
            return {}

        row = data.iloc[0]

        summary = {}
        for col in ['pe', 'pe_ttm', 'pb', 'total_mv', 'circ_mv']:
            if col in data.columns:
                summary[col] = float(row[col])

        return summary

    def _generate_strategy_suggestions(self, strategy_desc: str) -> List[str]:
        """生成策略建议"""
        suggestions = []

        # 基于描述内容提供建议
        if '均线' in strategy_desc or 'MA' in strategy_desc:
            suggestions.extend([
                "使用移动平均线（MA）作为趋势指标",
                "建议参数：短期MA=5-10日，长期MA=20-60日",
                "交易信号：短期均线上穿长期均线时买入，下穿时卖出"
            ])

        if '网格' in strategy_desc:
            suggestions.extend([
                "网格交易适合震荡市场",
                "建议设置网格间距：2%-5%",
                "需要确定初始基准价和网格数量"
            ])

        if '突破' in strategy_desc:
            suggestions.extend([
                "突破策略需要明确突破的定义",
                "建议结合成交量确认突破的有效性",
                "设置止损位以控制风险"
            ])

        # 通用建议
        suggestions.extend([
            "建议先在历史数据上进行回测",
            "注意交易成本和滑点的影响",
            "合理设置仓位和止损"
        ])

        return suggestions[:6]  # 限制建议数量

    def _get_query_suggestions(self) -> List[str]:
        """获取查询建议"""
        return [
            "查询股票价格：'获取茅台最近一个月的价格'",
            "查询财务数据：'查询平安银行的市盈率和市净率'",
            "策略开发：'帮我开发一个双均线交易策略'",
            "市场分析：'分析最近一周的科技股表现'"
        ]

    def chat(self, message: str) -> str:
        """
        对话式接口

        Args:
            message: 用户消息

        Returns:
            AI回复
        """
        result = self.query(message)

        response = f"🤖 {result['message']}\n"

        if result.get('success') and result.get('summary'):
            response += f"\n📊 数据摘要:\n"
            for key, value in result['summary'].items():
                response += f"  • {key}: {value}\n"

        if result.get('suggestions'):
            response += f"\n💡 建议:\n"
            for i, suggestion in enumerate(result['suggestions'], 1):
                response += f"  {i}. {suggestion}\n"

        if result.get('next_steps'):
            response += f"\n📋 后续步骤:\n"
            for step in result['next_steps']:
                response += f"  {step}\n"

        return response


# 便捷函数
def create_ai_assistant(token: Optional[str] = None) -> EasyXTAI:
    """创建AI助手实例"""
    return EasyXTAI(token)


if __name__ == "__main__":
    # 测试AI助手
    logger.info("🤖 EasyXT AI助手测试\n")

    ai = create_ai_assistant()

    # 测试查询
    test_queries = [
        "获取茅台最近一个月的价格",
        "查询平安银行的市盈率",
        "帮我开发一个双均线策略"
    ]

    for query in test_queries:
        logger.info(f"\n用户: {query}")
        logger.info(f"AI: {ai.chat(query)}")
        logger.info("-" * 50)
