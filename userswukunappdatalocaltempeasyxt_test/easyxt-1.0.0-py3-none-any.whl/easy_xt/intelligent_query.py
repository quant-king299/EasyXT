# -*- coding: utf-8 -*-
import logging

logger = logging.getLogger(__name__)
#!/usr/bin/env python3
"""
智能数据查询模块
将自然语言转换为精准的数据查询操作

主要功能：
- 自然语言到SQL/API的转换
- 复杂条件组合查询
- 跨数据源查询
- 智能结果聚合

作者: 王者quant
版本: 1.0.0
"""

import re
import pandas as pd
from typing import Dict, List, Optional, Any, Union, Tuple
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class QueryCondition:
    """查询条件类"""

    def __init__(self, field: str, operator: str, value: Any):
        self.field = field
        self.operator = operator  # >, <, =, >=, <=, !=, in, like
        self.value = value

    def to_dict(self) -> Dict[str, Any]:
        return {
            'field': self.field,
            'operator': self.operator,
            'value': self.value
        }

    def __repr__(self):
        return f"{self.field} {self.operator} {self.value}"


class NaturalLanguageParser:
    """自然语言解析器"""

    def __init__(self):
        self.operator_map = {
            '大于': '>',
            '小于': '<',
            '等于': '=',
            '大于等于': '>=',
            '小于等于': '<=',
            '不等于': '!=',
            '包含': 'like',
            '在': 'in'
        }

        self.field_synonyms = {
            '价格': ['price', 'close', '收盘价'],
            '开盘价': ['open', '开盘'],
            '最高价': ['high', '最高'],
            '最低价': ['low', '最低'],
            '成交量': ['volume', '成交量', '成交'],
            '成交额': ['amount', '成交额'],
            '市盈率': ['pe', 'PE', '市盈'],
            '市净率': ['pb', 'PB', '市净'],
            '市值': ['total_mv', '总市值', '市值'],
            '换手率': ['turnover_rate', '换手']
        }

        self.industry_keywords = [
            '银行', '证券', '保险', '地产', '医药', '生物', '科技', '电子',
            '通信', '计算机', '软件', '半导体', '新能源', '汽车', '机械',
            '化工', '钢铁', '煤炭', '有色', '建材', '建筑', '家电', '食品',
            '饮料', '纺织', '服装', '轻工', '商贸', '零售', '交通运输'
        ]

    def parse(self, query: str) -> Dict[str, Any]:
        """
        解析自然语言查询

        Args:
            query: 自然语言查询字符串

        Returns:
            解析后的查询结构
        """
        query = query.strip()

        # 识别查询类型
        query_type = self._identify_query_type(query)

        # 提取股票范围
        stock_scope = self._extract_stock_scope(query)

        # 提取筛选条件
        conditions = self._extract_conditions(query)

        # 提取排序要求
        sort_by = self._extract_sorting(query)

        # 提取数据范围
        data_range = self._extract_data_range(query)

        return {
            'type': query_type,
            'stock_scope': stock_scope,
            'conditions': conditions,
            'sort_by': sort_by,
            'data_range': data_range,
            'raw_query': query
        }

    def _identify_query_type(self, query: str) -> str:
        """识别查询类型"""
        if any(word in query for word in ['筛选', '找出', '寻找', '符合']):
            return 'filter'
        elif any(word in query for word in ['排序', '排名', 'TOP', '前']):
            return 'rank'
        elif any(word in query for word in ['统计', '汇总', '平均', '总计']):
            return 'aggregate'
        else:
            return 'simple_query'

    def _extract_stock_scope(self, query: str) -> Dict[str, Any]:
        """提取股票范围"""
        scope = {
            'type': 'all',  # all, industry, concept, specific
            'value': None
        }

        # 检查是否指定行业
        for industry in self.industry_keywords:
            if industry in query:
                scope['type'] = 'industry'
                scope['value'] = industry
                return scope

        # 检查是否指定概念板块
        if '概念' in query or '板块' in query:
            concept_match = re.search(r'(.+?)(?:概念|板块)', query)
            if concept_match:
                scope['type'] = 'concept'
                scope['value'] = concept_match.group(1)
                return scope

        # 检查是否指定具体股票
        codes = re.findall(r'\d{6}', query)
        if codes:
            scope['type'] = 'specific'
            scope['value'] = codes
            return scope

        return scope

    def _extract_conditions(self, query: str) -> List[QueryCondition]:
        """提取筛选条件"""
        conditions = []

        # 数值比较条件
        patterns = [
            r'(\w+)[\s]*(?:大于|>)[\s]*([\d.]+)',
            r'(\w+)[\s]*(?:小于|<)[\s]*([\d.]+)',
            r'(\w+)[\s]*(?:等于|=)[\s]*([\d.]+)',
            r'([\d.]+)[\s]*(?:以下|以内)',  # 简化处理
        ]

        for pattern in patterns:
            matches = re.findall(pattern, query)
            for match in matches:
                if len(match) == 2:
                    field, value = match
                    operator = '='
                    if '大于' in pattern or '>' in pattern:
                        operator = '>'
                    elif '小于' in pattern or '<' in pattern:
                        operator = '<'

                    conditions.append(QueryCondition(field, operator, float(value)))

        return conditions

    def _extract_sorting(self, query: str) -> Optional[Dict[str, str]]:
        """提取排序要求"""
        if '升序' in query or '从低到高' in query:
            return {'order': 'asc'}
        elif '降序' in query or '从高到低' in query or '降' in query:
            return {'order': 'desc'}
        return None

    def _extract_data_range(self, query: str) -> Dict[str, str]:
        """提取数据范围"""
        range_info = {}

        # 时间范围
        time_patterns = [
            (r'最近(\d+)(?:天|日|个交易日)', 'days'),
            (r'最近(\d+)(?:周|星期)', 'weeks'),
            (r'最近(\d+)月', 'months'),
            (r'今年', 'year'),
            (r'本月', 'month'),
        ]

        for pattern, unit in time_patterns:
            match = re.search(pattern, query)
            if match:
                if unit == 'year':
                    range_info['period'] = 'ytd'
                elif unit == 'month':
                    range_info['period'] = 'mtd'
                else:
                    range_info['period'] = f'{match.group(1)}{unit}'

                break

        return range_info


class IntelligentQueryExecutor:
    """智能查询执行器"""

    def __init__(self, api, tushare_integration=None):
        """
        初始化查询执行器

        Args:
            api: EasyXT API实例
            tushare_integration: Tushare集成实例
        """
        self.api = api
        self.tushare = tushare_integration
        self.parser = NaturalLanguageParser()

    def execute(self, natural_query: str) -> Dict[str, Any]:
        """
        执行自然语言查询

        Args:
            natural_query: 自然语言查询字符串

        Returns:
            查询结果
        """
        # 解析查询
        parsed_query = self.parser.parse(natural_query)

        result = {
            'query': natural_query,
            'parsed_query': parsed_query,
            'success': False,
            'data': None,
            'message': '',
            'metadata': {}
        }

        try:
            # 根据查询类型执行
            if parsed_query['type'] == 'filter':
                result.update(self._execute_filter_query(parsed_query))
            elif parsed_query['type'] == 'rank':
                result.update(self._execute_rank_query(parsed_query))
            elif parsed_query['type'] == 'aggregate':
                result.update(self._execute_aggregate_query(parsed_query))
            else:
                result.update(self._execute_simple_query(parsed_query))

        except Exception as e:
            result['message'] = f"查询执行失败: {str(e)}"
            logger.error(f"Query execution failed: {e}")

        return result

    def _execute_filter_query(self, parsed_query: Dict[str, Any]) -> Dict[str, Any]:
        """执行筛选查询"""
        conditions = parsed_query['conditions']
        stock_scope = parsed_query['stock_scope']

        # 获取基础数据
        base_data = self._get_base_data(stock_scope, parsed_query['data_range'])

        if base_data is None or base_data.empty:
            return {
                'success': False,
                'message': '无法获取基础数据'
            }

        # 应用筛选条件
        filtered_data = self._apply_conditions(base_data, conditions)

        return {
            'success': True,
            'data': filtered_data,
            'message': f'筛选完成，找到 {len(filtered_data)} 只股票',
            'metadata': {
                'total_stocks': len(base_data),
                'filtered_stocks': len(filtered_data),
                'conditions_applied': len(conditions)
            }
        }

    def _execute_rank_query(self, parsed_query: Dict[str, Any]) -> Dict[str, Any]:
        """执行排名查询"""
        stock_scope = parsed_query['stock_scope']

        # 获取数据
        base_data = self._get_base_data(stock_scope, parsed_query['data_range'])

        if base_data is None or base_data.empty:
            return {
                'success': False,
                'message': '无法获取数据'
            }

        # 应用筛选条件
        if parsed_query['conditions']:
            base_data = self._apply_conditions(base_data, parsed_query['conditions'])

        # 排序
        sort_config = parsed_query['sort_by'] or {'order': 'desc'}
        # 简化处理：按市值排序
        if 'total_mv' in base_data.columns:
            base_data = base_data.sort_values('total_mv', ascending=sort_config['order'] == 'asc')

        # 提取TOP N
        top_match = re.search(r'TOP\s*(\d+)|前\s*(\d+)|排名前\s*(\d+)', parsed_query['raw_query'])
        top_n = int(top_match.group(1) or top_match.group(2) or top_match.group(3) or 10)

        ranked_data = base_data.head(top_n)

        return {
            'success': True,
            'data': ranked_data,
            'message': f'排名前 {top_n} 的股票',
            'metadata': {
                'top_n': top_n,
                'sort_order': sort_config['order']
            }
        }

    def _execute_aggregate_query(self, parsed_query: Dict[str, Any]) -> Dict[str, Any]:
        """执行聚合查询"""
        stock_scope = parsed_query['stock_scope']
        base_data = self._get_base_data(stock_scope, parsed_query['data_range'])

        if base_data is None or base_data.empty:
            return {
                'success': False,
                'message': '无法获取数据'
            }

        # 简单统计
        stats = {
            'count': len(base_data),
            'mean_pe': base_data['pe'].mean() if 'pe' in base_data.columns else None,
            'mean_pb': base_data['pb'].mean() if 'pb' in base_data.columns else None,
            'total_mv': base_data['total_mv'].sum() if 'total_mv' in base_data.columns else None
        }

        return {
            'success': True,
            'data': pd.DataFrame([stats]),
            'message': '统计完成',
            'metadata': {'aggregation_type': 'basic_stats'}
        }

    def _execute_simple_query(self, parsed_query: Dict[str, Any]) -> Dict[str, Any]:
        """执行简单查询"""
        stock_scope = parsed_query['stock_scope']
        data_range = parsed_query['data_range']

        base_data = self._get_base_data(stock_scope, data_range)

        if base_data is None or base_data.empty:
            return {
                'success': False,
                'message': '无法获取数据'
            }

        # 应用筛选条件
        if parsed_query['conditions']:
            base_data = self._apply_conditions(base_data, parsed_query['conditions'])

        return {
            'success': True,
            'data': base_data,
            'message': f'查询完成，共 {len(base_data)} 条记录'
        }

    def _get_base_data(self, stock_scope: Dict[str, Any], data_range: Dict[str, str]) -> Optional[pd.DataFrame]:
        """获取基础数据"""
        try:
            # 确定查询日期
            trade_date = datetime.now().strftime('%Y%m%d')

            # 根据股票范围获取数据
            if stock_scope['type'] == 'all':
                if self.tushare and self.tushare.is_available():
                    return self.tushare.ts_pro.daily_basic(
                        trade_date=trade_date,
                        fields='ts_code,trade_date,close,pe,pb,total_mv,circ_mv,turnover_rate'
                    )
            elif stock_scope['type'] == 'specific':
                codes = stock_scope['value']
                if self.api:
                    # 使用EasyXT API
                    data_list = []
                    for code in codes:
                        data = self.api.get_price(code, period='1d', count=1)
                        if data is not None and not data.empty:
                            data_list.append(data)

                    if data_list:
                        return pd.concat(data_list, ignore_index=True)

            return None

        except Exception as e:
            logger.error(f"Failed to get base data: {e}")
            return None

    def _apply_conditions(self, data: pd.DataFrame, conditions: List[QueryCondition]) -> pd.DataFrame:
        """应用筛选条件"""
        filtered_data = data.copy()

        for condition in conditions:
            if condition.field in filtered_data.columns:
                if condition.operator == '>':
                    filtered_data = filtered_data[filtered_data[condition.field] > condition.value]
                elif condition.operator == '<':
                    filtered_data = filtered_data[filtered_data[condition.field] < condition.value]
                elif condition.operator == '>=':
                    filtered_data = filtered_data[filtered_data[condition.field] >= condition.value]
                elif condition.operator == '<=':
                    filtered_data = filtered_data[filtered_data[condition.field] <= condition.value]
                elif condition.operator == '=':
                    filtered_data = filtered_data[filtered_data[condition.field] == condition.value]

        return filtered_data


class IntelligentQueryInterface:
    """智能查询接口"""

    def __init__(self, api=None, tushare_integration=None):
        """
        初始化智能查询接口

        Args:
            api: EasyXT API实例
            tushare_integration: Tushare集成实例
        """
        if api is None:
            try:
                from . import get_api
                api = get_api()
            except Exception:
                pass

        self.executor = IntelligentQueryExecutor(api, tushare_integration)

    def ask(self, question: str) -> Union[pd.DataFrame, Dict[str, Any]]:
        """
        自然语言查询接口

        Args:
            question: 自然语言问题

        Returns:
            查询结果（DataFrame或结果字典）

        Examples:
            >>> query.ask("找出市盈率小于10的银行股")
            >>> query.ask("市值排名前20的科技公司")
            >>> query.ask("最近一个月涨幅超过20%的股票")
        """
        result = self.executor.execute(question)

        if result['success']:
            return result['data']
        else:
            return {
                'error': result['message'],
                'suggestions': [
                    "请尝试更具体的描述",
                    "确认股票代码或名称正确",
                    "检查网络连接"
                ]
            }

    def filter_stocks(self, criteria: str) -> pd.DataFrame:
        """
        筛选股票

        Args:
            criteria: 筛选条件描述

        Returns:
            符合条件的股票列表
        """
        result = self.executor.execute(f"筛选{criteria}")
        return result['data'] if result['success'] else pd.DataFrame()

    def rank_stocks(self, by: str, top_n: int = 10, ascending: bool = False) -> pd.DataFrame:
        """
        股票排名

        Args:
            by: 排序依据（如"市值"、"市盈率"）
            top_n: 返回前N名
            ascending: 是否升序

        Returns:
            排名后的股票列表
        """
        order = "升序" if ascending else "降序"
        query = f"按{by}{order}排名，TOP {top_n}"

        result = self.executor.execute(query)
        return result['data'] if result['success'] else pd.DataFrame()


# 便捷函数
def create_intelligent_query(api=None, tushare_token=None) -> IntelligentQueryInterface:
    """创建智能查询接口"""
    tushare_integration = None
    if tushare_token:
        from .ai_assistant import TushareSkillIntegration
        tushare_integration = TushareSkillIntegration(tushare_token)

    return IntelligentQueryInterface(api, tushare_integration)


if __name__ == "__main__":
    # 测试智能查询
    logger.info("🔍 智能数据查询测试\n")

    query = create_intelligent_query()

    test_queries = [
        "找出市盈率小于10的股票",
        "市值排名前5的股票",
        "查询银行股的平均市净率"
    ]

    for q in test_queries:
        logger.info(f"\n查询: {q}")
        result = query.ask(q)
        logger.info(f"结果: {result}")
        logger.info("-" * 50)
