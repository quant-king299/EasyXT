import logging

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)



logger = logging.getLogger(__name__)

#!/usr/bin/env python3

# -*- coding: utf-8 -*-

"""

EasyXT AI命令行工具

提供交互式AI对话界面进行量化交易操作



主要功能：

- 自然语言数据查询

- 策略开发辅助

- 代码生成

- 实时行情监控



作者: 王者quant

版本: 1.0.0

"""



import sys

import os

import argparse

from typing import Optional



# 添加项目根目录到路径

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if project_root not in sys.path:

    sys.path.insert(0, project_root)





class AIChatInterface:

    """AI对话界面"""



    def __init__(self, token: Optional[str] = None):

        """初始化AI对话界面"""

        self.running = True



        # 导入AI助手

        try:

            from easy_xt.ai_assistant import EasyXTAI

            self.ai = EasyXTAI(token)

            self.init_success = True

        except Exception as e:

            logger.info(f"❌ AI助手初始化失败: {e}")

            self.init_success = False



        # 导入策略助手

        try:

            from strategies.ai_strategy_helper import AIStrategyHelper

            self.strategy_helper = AIStrategyHelper()

        except Exception as e:

            logger.info(f"⚠️  策略助手加载失败: {e}")

            self.strategy_helper = None



        # 导入智能查询

        try:

            from easy_xt.intelligent_query import create_intelligent_query

            self.query_engine = create_intelligent_query(token=token)

        except Exception as e:

            logger.info(f"⚠️  智能查询加载失败: {e}")

            self.query_engine = None



        self.command_map = {

            '/help': self.show_help,

            '/exit': self.exit_chat,

            '/clear': self.clear_screen,

            '/data': self.data_query_mode,

            '/strategy': self.strategy_mode,

            '/code': self.code_generation_mode,

            '/status': self.show_status,

        }



    def show_welcome(self):

        """显示欢迎信息"""

        print("""

╔══════════════════════════════════════════════════════════════╗

║              🤖 EasyXT AI助手 - 交互式对话界面                ║

║                    版本: 1.0.0                               ║

║                  作者: 王者quant                             ║

╚══════════════════════════════════════════════════════════════╝



🎯 功能特色:

  • 自然语言数据查询

  • 智能策略生成

  • 代码自动生成

  • 实时行情分析



💡 使用技巧:

  - 直接输入问题，如 "获取茅台最近的价格"

  - 使用 /help 查看所有命令

  - 使用 /exit 退出程序



━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        """)



    def show_help(self):

        """显示帮助信息"""

        print("""

📚 命令列表:



基础命令:

  /help          - 显示此帮助信息

  /exit          - 退出程序

  /clear         - 清屏

  /status        - 显示系统状态



功能模式:

  /data          - 进入数据查询模式

  /strategy      - 进入策略开发模式

  /code          - 进入代码生成模式



查询示例:

  • "获取茅台最近一个月的价格"

  • "查询平安银行的市盈率"

  • "找出市值排名前10的银行股"



策略示例:

  • "帮我写一个双均线策略"

  • "开发一个网格交易策略"

  • "生成一个突破策略"



━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        """)



    def exit_chat(self):

        """退出对话"""

        logger.info("\n👋 感谢使用EasyXT AI助手，再见！")

        self.running = False



    def clear_screen(self):

        """清屏"""

        os.system('cls' if os.name == 'nt' else 'clear')



    def show_status(self):

        """显示系统状态"""

        tushare_status = "✅" if self.ai.tushare_integration.is_available() else "❌"

        api_status = "✅" if self.ai.api else "❌"

        strategy_status = "✅" if self.strategy_helper else "❌"

        query_status = "✅" if self.query_engine else "❌"



        status_text = f"""

📊 系统状态:



AI助手:

  • 状态: ✅ 正常运行

  • Tushare: {tushare_status} 状态

  • EasyXT API: {api_status} 状态



策略助手:

  • 状态: {strategy_status}



智能查询:

  • 状态: {query_status}



━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        """

        logger.info(status_text)



    def data_query_mode(self):

        """数据查询模式"""

        logger.info("\n📊 进入数据查询模式")

        logger.info("💡 输入查询问题，输入 'back' 返回主菜单\n")



        while True:

            try:

                query = input("🔍 数据查询> ").strip()



                if query.lower() in ['back', 'exit', 'quit']:

                    break



                if not query:

                    continue



                # 执行查询

                if self.ai:

                    result = self.ai.query(query)

                    logger.info(f"\n{self.ai.chat(query)}\n")

                else:

                    logger.info("❌ AI助手不可用")



            except KeyboardInterrupt:

                logger.info("\n⚠️  按Ctrl+C返回主菜单")

                break

            except Exception as e:

                logger.info(f"❌ 查询失败: {e}\n")



    def strategy_mode(self):

        """策略开发模式"""

        logger.info("\n🎯 进入策略开发模式")

        logger.info("💡 描述你的策略需求，输入 'back' 返回主菜单\n")



        while True:

            try:

                query = input("🎯 策略开发> ").strip()



                if query.lower() in ['back', 'exit', 'quit']:

                    break



                if not query:

                    continue



                # 生成策略

                if self.strategy_helper:

                    result = self.strategy_helper.suggest_strategy(query)



                    logger.info(f"\n📊 推荐策略: {result['recommended_strategy']}")

                    logger.info(f"📝 说明: {result['explanation']}\n")



                    if result['generated_code']:

                        logger.info("💻 生成的策略代码:")

                        logger.info("-" * 60)

                        logger.info(result['generated_code'][:800])

                        if len(result['generated_code']) > 800:

                            logger.info("\n... (代码已截断，完整代码已生成)")

                        logger.info("-" * 60)



                    logger.info("\n💡 优化建议:")

                    for i, tip in enumerate(result['optimization_tips'], 1):

                        logger.info(f"  {i}. {tip}")

                    print()



                else:

                    logger.info("❌ 策略助手不可用")



            except KeyboardInterrupt:

                logger.info("\n⚠️  按Ctrl+C返回主菜单")

                break

            except Exception as e:

                logger.info(f"❌ 生成失败: {e}\n")



    def code_generation_mode(self):

        """代码生成模式"""

        logger.info("\n💻 进入代码生成模式")

        logger.info("💡 描述你要生成的代码，输入 'back' 返回主菜单\n")



        while True:

            try:

                query = input("💻 代码生成> ").strip()



                if query.lower() in ['back', 'exit', 'quit']:

                    break



                if not query:

                    continue



                # 生成代码

                if self.strategy_helper:

                    code = self.strategy_helper.generate_backtest_code(query)



                    logger.info("\n💻 生成的回测代码:")

                    logger.info("=" * 60)

                    logger.info(code)

                    logger.info("=" * 60)

                    logger.info("\n✅ 代码已生成，你可以复制到文件中运行\n")



                else:

                    logger.info("❌ 策略助手不可用")



            except KeyboardInterrupt:

                logger.info("\n⚠️  按Ctrl+C返回主菜单")

                break

            except Exception as e:

                logger.info(f"❌ 生成失败: {e}\n")



    def process_command(self, user_input: str):

        """处理命令"""

        if user_input in self.command_map:

            self.command_map[user_input]()

            return True

        return False



    def run(self):

        """运行对话界面"""

        if not self.init_success:

            logger.info("❌ 初始化失败，无法启动")

            return



        self.show_welcome()



        while self.running:

            try:

                # 获取用户输入

                user_input = input("🤖 EasyXT> ").strip()



                if not user_input:

                    continue



                # 处理命令

                if self.process_command(user_input):

                    continue



                # 处理普通查询

                result = self.ai.chat(user_input)

                logger.info(f"\n{result}\n")



            except KeyboardInterrupt:

                logger.info("\n⚠️  使用 /exit 命令退出程序\n")

            except EOFError:

                logger.info("\n👋 再见！")

                break

            except Exception as e:

                logger.info(f"❌ 发生错误: {e}\n")





def main():

    """主函数"""

    parser = argparse.ArgumentParser(description='EasyXT AI命令行工具')

    parser.add_argument('--token', '-t', type=str, help='Tushare API Token')

    parser.add_argument('--query', '-q', type=str, help='直接执行查询')

    parser.add_argument('--interactive', '-i', action='store_true',

                       help='启动交互式对话模式（默认）')



    args = parser.parse_args()



    # 创建对话界面

    chat = AIChatInterface(token=args.token)



    # 直接查询模式

    if args.query:

        result = chat.ai.chat(args.query)

        logger.info(result)

        return



    # 交互式模式（默认）

    chat.run()





if __name__ == "__main__":

    main()

