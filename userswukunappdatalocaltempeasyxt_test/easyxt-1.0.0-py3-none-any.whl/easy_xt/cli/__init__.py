"""
EasyXT CLI模块
提供命令行工具
"""

from .ai_cli import AIChatInterface, main

__all__ = ['AIChatInterface', 'main']
